import { combineReducers } from 'redux';
import postsReducer from './postsReducer';
import userReducer from './userReducer';


///Song Start
const songsReducer =()=>{
    return [
        {title:'No Scrubs', duration : '4.05'},
        {title:'Macaren', duration : '2.05'},
        {title:'All Start', duration : '3.15'},
        {title:'I want it That way', duration : '1.45'},
    ];
};

const selectedSongReducer =(selectedSong=null, action)=>{
    if(action.type==='SONG_SELECTED'){
        return action.payload;
    }
    return selectedSong;
}
//Song End

///Post Start


///Post End


export default combineReducers({
    ///For Song
    songs:songsReducer,
    selectedSong:selectedSongReducer,
    //Post
    posts:postsReducer,
    users:userReducer
})